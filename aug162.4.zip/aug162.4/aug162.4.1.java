public class ProblemSet2_1 {
    public static void main(String[] args) {
        System.out.println("  xxxx  ");
        System.out.println(" x    x ");
        System.out.println("x x  x x");
        System.out.println("x      x");
        System.out.println("x x  x x");
        System.out.println("x  xx  x");
        System.out.println(" x    x");
        System.out.println("  xxxx");
        
    }
}