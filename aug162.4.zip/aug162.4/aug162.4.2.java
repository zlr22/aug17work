public class ProblemSet2_1 {
    public static void main(String[] args) {
        System.out.println("xxxxxxxx");
        System.out.println("x      x");
        System.out.println("xxxxxxxx");
        System.out.println("xxxxxxxx");
        System.out.println("xxxxxxxx");
        System.out.println("xxxxxxxx");
        System.out.println("xxxxxxxx");
        System.out.println("xxxxxxxx");
        
       // Lock
        
        
        
    }
}